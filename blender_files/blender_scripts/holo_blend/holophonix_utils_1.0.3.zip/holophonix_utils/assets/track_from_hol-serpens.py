import bpy
#import os
import json
import sys
import math

"""Functions and classes related to coordinate system conversion
"""
import numpy
from numpy import radians


def cart2pol(x, y, units='deg'):
    """Convert from cartesian to polar coordinates.

    :usage:

        theta, radius = cart2pol(x, y, units='deg')

    units refers to the units (rad or deg) for theta that should be returned
    """
    radius = numpy.hypot(x, y)
    theta = numpy.arctan2(y, x)
    if units in ('deg', 'degs'):
        theta = theta * 180 / numpy.pi
    return theta, radius



def pol2cart(theta, radius, units='deg'):
    """Convert from polar to cartesian coordinates.

    usage::

        x,y = pol2cart(theta, radius, units='deg')

    """
    if units in ('deg', 'degs'):
        theta = theta * numpy.pi / 180.0
    xx = radius * numpy.cos(theta)
    yy = radius * numpy.sin(theta)

    return xx, yy



def cart2sph(z, y, x):
    """Convert from cartesian coordinates (x,y,z) to spherical (elevation,
    azimuth, radius). Output is in degrees.

    usage:
        array3xN[el,az,rad] = cart2sph(array3xN[x,y,z])
        OR
        elevation, azimuth, radius = cart2sph(x,y,z)

        If working in DKL space, z = Luminance, y = S and x = LM
    """
    width = len(z)

    elevation = numpy.empty([width, width])
    radius = numpy.empty([width, width])
    azimuth = numpy.empty([width, width])

    radius = numpy.sqrt(x**2 + y**2 + z**2)
    azimuth = numpy.arctan2(y, x)
    # Calculating the elevation from x,y up
    elevation = numpy.arctan2(z, numpy.sqrt(x**2 + y**2))

    # convert azimuth and elevation angles into degrees
    azimuth *= 180.0 / numpy.pi
    elevation *= 180.0 / numpy.pi

    sphere = numpy.array([elevation, azimuth, radius])
    sphere = numpy.rollaxis(sphere, 0, 3)

    return sphere



def sph2cart(*args):
    """Convert from spherical coordinates (elevation, azimuth, radius)
    to cartesian (x,y,z).

    usage:
        array3xN[x,y,z] = sph2cart(array3xN[el,az,rad])
        OR
        x,y,z = sph2cart(elev, azim, radius)
    """
    if len(args) == 1:  # received an Nx3 array
        elev = args[0][0, :]
        azim = args[0][1, :]
        radius = args[0][2, :]
        returnAsArray = True
    elif len(args) == 3:
        elev = args[0]
        azim = args[1]
        radius = args[2]
        returnAsArray = False

    z = radius * numpy.sin(radians(elev))
    x = radius * numpy.cos(radians(elev)) * numpy.cos(radians(azim))
    y = radius * numpy.cos(radians(elev)) * numpy.sin(radians(azim))
    if returnAsArray:
        return numpy.asarray([x, y, z])
    else:
        return x, y, z

for obj in bpy.context.scene.objects:
    if "track" in obj.name:
        bpy.data.objects[obj.name].select_set(True)
        print(obj.name, ' deleted')
        bpy.ops.object.delete()
        for block in bpy.data.meshes:
            if block.users == 0:
                bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            if block.users == 0:
                bpy.data.materials.remove(block)

 
#file_path_rel = '//Assets/amadeus.blend'
#preset_file_path_rel = '//hol/DEWI23.hol'
#coord_convert_file_rel = '//scripts/coord_conversion.py'
#
#print(bpy.path.abspath(file_path_rel))
#file_path = bpy.path.abspath(file_path_rel)
#preset_file_path = bpy.path.abspath(preset_file_path_rel)
#coord_convert_file = bpy.path.abspath(coord_convert_file_rel)
#from coord_conv import sph2cart
inner_path = 'Object'


"""
Read *.hol file content
"""
with open(preset_file_path) as f:
    preset_content = json.load(f)
    preset_dict = preset_content['hol']
    keys = list(preset_dict.keys())
    audio_engine_dict = preset_content['ae']
    
"""
Search in content for matching parameters
"""
for i in range(1,128):
    sph_coord = [0,0,0]
    cart_coord = [0,0,0]
    trk_type = ""
    track_color = [0,0,0,0]
    trk_pan = 0
    trk_tilt = 0
    trk_roll90deg = False
    speaker = '/speaker/'
    track = '/track/'
    params = ['/color','/azim','/elev','/dist','/view3D/file3D','/view3D/roll90deg','/view3D/pan','/view3D/tilt',"/name"]
    rotation_mode = 'XYZ'
    for param in params:
        tuple = (track,str(i),param)
        tuple = ''.join(tuple)
        
        if param == params[1]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[0] = p_tuple[0]
                print(tuple,'azim:',p_tuple[0])
        elif param == params[2]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[1] = p_tuple[0]
                print(tuple,'elev: ',p_tuple[0])
        elif param == params[3]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[2] = p_tuple[0]
                print(tuple,'dist: ',p_tuple[0])
                cart_coord = sph2cart(float(sph_coord[1]),float(sph_coord[0]),float(sph_coord[2]))
                print('cartesian coordinates: ',cart_coord)
                
        elif param == params[4]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                end_loc = len(p_tuple)-5
                trk_name = str(p_tuple[0])[18:end_loc]
                print(tuple,trk_name)
                bpy.ops.wm.append(
                    directory=os.path.join(file_path, inner_path),
                    filename=trk_name
                    )
                for obj in bpy.context.selected_objects:
                    digits = len(str(i))
                    if digits == 1:
                        obj.name = 'track.00'+str(i)+'.'+trk_name
                        obj.data.name = 'track.00'+str(i)+'.'+trk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
#                        material = bpy.data.materials.new(name = 'track.00'+str(i)+'.'+trk_name+'.mat')
#                        obj.data.materials.append(material)
#                        bpy.data.materials['track.00'+str(i)+'.'+trk_name+'.mat'].diffuse_color = track_color
                    elif digits == 2:
                        obj.name = 'track.0'+str(i)+'.'+trk_name
                        obj.data.name = 'track.0'+str(i)+'.'+trk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
#                        material = bpy.data.materials.new(name = 'track.0'+str(i)+'.'+trk_name+'.mat')
#                        obj.data.materials.append(material)
#                        bpy.data.materials['track.0'+str(i)+'.'+trk_name+'.mat'].diffuse_color = track_color
                    else:
                        obj.name = 'track.'+str(i)+'.'+trk_name
                        obj.data.name = 'track.'+str(i)+'.'+trk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
#                        material = bpy.data.materials.new(name = 'track.'+str(i)+'.'+trk_name+'.mat')
#                        obj.data.materials.append(material)
#                        bpy.data.materials['track.'+str(i)+'.'+trk_name+'.mat'].diffuse_color = track_color
                    
        elif param == params[0]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                track_color = p_tuple
                
        elif param == params[7]:
            obj.lock_rotation[1] = True
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                trk_tilt = p_tuple[0]
                for obj in bpy.context.selected_objects:
                    obj.rotation_mode = rotation_mode
                    """
                    if trk_roll90deg == True:
                        obj.rotation_euler[1] = math.radians(-float(trk_tilt))
                    else:
                        obj.rotation_euler[2] = math.radians(float(trk_tilt))
                    """
                    obj.rotation_euler[0] = math.radians(float(trk_tilt))
                    if float(trk_pan) > 90:
                        if trk_roll90deg == True:
                            print('condition true')
                            obj.rotation_euler[0] =  -1*(obj.rotation_euler[0])
                    obj.lock_rotation[0] = True
        elif param == params[6]:
            obj.lock_rotation[2] = True
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                trk_pan = p_tuple[0]
                for obj in bpy.context.selected_objects:
                    obj.rotation_mode = rotation_mode
                    if trk_roll90deg == True:
                        obj.rotation_euler[1] = math.radians(float(trk_pan))
                        if float(trk_pan) > 90:
                            print('modified to',obj.rotation_euler[0])
                            obj.rotation_euler[2] = math.radians(-90)
                            
                    else:
                        obj.rotation_euler[1] = math.radians(-float(trk_pan))
#                    obj.rotation_euler[1] = math.radians(float(trk_pan))
                    obj.lock_rotation[1] = True
                    
                        
        elif param == params[5]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                trk_roll90deg = p_tuple[0]
                if trk_roll90deg == True:
                    for obj in bpy.context.selected_objects:
                        rotation_mode = 'YZX'
                        obj.rotation_euler[2] = math.radians(90)
                        obj.lock_rotation[2] = True
                    
        else:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple[0])
                    
    
"""
retrieve list of speaker models in assets file
"""
"""
with bpy.data.libraries.load(file_path) as (data_from, data_to):
    object_names = [name for name in data_from.objects]
#print(object_names)

for i in range(1,len(audio_engine_dict)):



i = 17
object_name = object_names[i]
 
bpy.ops.wm.append(
    directory=os.path.join(file_path, inner_path),
    filename=object_name
    )

for obj in bpy.context.selected_objects:
    obj.name = object_name
    obj.data.name = object_name
"""
sph_coord = [0,0,0]
cart_coord = [0,0,0]
track_name =''
new_name = ''
path_num =''
objects = [obj.name for obj in bpy.context.scene.objects]
track_list = [s for s in objects if "track" in s]
#print('longueur de la liste :',len(audio_engine_dict))
for i in range(0,len(audio_engine_dict)-1):
    
    
    
    params = ['color','azim','elev','dist',"name"]
    if "/track/" in audio_engine_dict[i]:
#        print(audio_engine_dict[i])
        if '"' in audio_engine_dict[i]:
            separate = str(audio_engine_dict[i]).split('"')
#            print('separate"',separate)
        else:
            separate = str(audio_engine_dict[i]).split()
#            print("separate ",separate)
        path = separate[0]
        path_details = path.split('/')
        if int(len(path_details)) > 1:

            if path_details[2] != "indices":
                path_num = path_details[2]
                if len(path_num) == 1:
                    path_num = '00'+path_num
                elif len(path_num) == 2:
                    path_num = '0'+path_num
                else:
                    path_num = path_num

#                print("track number :",path_num,"details",path_details)

                if int(len(path_details)) == 4:
                    path_key = path_details[3]
#                    print("track key :",path_key)
                    matching = [s for s in track_list if str(path_num) in s]
#                    print("old name",str((matching)[0]))
                    if "name" in path_key:
                        print("that's name")
                        new_name = str(separate[1])
#                        print("new name",new_name)
                        bpy.context.scene.objects[str((matching)[0])].name = "track."+str(path_num)+"."+str(new_name)
#                        bpy.data.objects["track."+str(path_num)+"."+str((matching)[0])].name = str(new_name)
                        bpy.context.scene.objects["track."+str(path_num)+"."+str(new_name)].data.name = "track."+str(path_num)+"."+str(new_name)
                    elif "color" in path_key:

                        del separate[0]
                        print("col_idx",separate)
                        col_idx = []
                        for item in separate:
                            col_idx.append(float(item)) 
                        material = bpy.data.materials.new(name = "track."+path_num+'.'+str(new_name)+'.mat')
                        bpy.context.scene.objects["track."+path_num+'.'+str(new_name)].data.materials.clear()
                        bpy.context.scene.objects["track."+path_num+'.'+str(new_name)].data.materials.append(material)
                        bpy.data.materials["track."+path_num+'.'+str(new_name)+'.mat'].diffuse_color = col_idx  
                    elif "azim" in path_key:
#                        print("azim",float(separate[1]))
                        sph_coord[0] = float(separate[1])
                    elif "elev" in path_key:
#                        print("elev",float(separate[1]))
                        sph_coord[1] = float(separate[1])
                    elif "dist" in path_key:
#                        print("dist",float(separate[1]))
                        sph_coord[2] = float(separate[1])
#                        print("sph_coord",sph_coord)
                        cart_coord = sph2cart(float(sph_coord[1]),float(sph_coord[0]),float(sph_coord[2]))
#                        print("cart_coord",cart_coord)
#                        print("path_num",path_num,"new name",new_name)
                        bpy.context.scene.objects["track."+path_num+'.'+str(new_name)].location[1] = float(cart_coord[0])
                        bpy.context.scene.objects["track."+path_num+'.'+str(new_name)].location[0] = float(cart_coord[1])
                        bpy.context.scene.objects["track."+path_num+'.'+str(new_name)].location[2] = float(cart_coord[2])


        
#        values = []
#        for j in range(1,len(separate)):
#            values.append(separate[j])