# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Holophonix_Utils",
    "author" : "Dewiweb", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 3),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper
import json
import math
import numpy
from numpy import radians


addon_keymaps = {}
_icons = None
class SNA_OT_Add_Speakers_994C8(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.add_speakers_994c8"
    bl_label = "Add_Speakers"
    bl_description = "replace actual speakers by those in imported hol preset file"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.hol', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        preset_file_path = self.filepath
        file_path = os.path.join(os.path.dirname(__file__), 'assets', 'amadeus.blend')
        Variable = None
        #import os
        import sys
        """Functions and classes related to coordinate system conversion
        """
        from numpy import radians

        def cart2pol(x, y, units='deg'):
            """Convert from cartesian to polar coordinates.
            :usage:
                theta, radius = cart2pol(x, y, units='deg')
            units refers to the units (rad or deg) for theta that should be returned
            """
            radius = numpy.hypot(x, y)
            theta = numpy.arctan2(y, x)
            if units in ('deg', 'degs'):
                theta = theta * 180 / numpy.pi
            return theta, radius

        def pol2cart(theta, radius, units='deg'):
            """Convert from polar to cartesian coordinates.
            usage::
                x,y = pol2cart(theta, radius, units='deg')
            """
            if units in ('deg', 'degs'):
                theta = theta * numpy.pi / 180.0
            xx = radius * numpy.cos(theta)
            yy = radius * numpy.sin(theta)
            return xx, yy

        def cart2sph(z, y, x):
            """Convert from cartesian coordinates (x,y,z) to spherical (elevation,
            azimuth, radius). Output is in degrees.
            usage:
                array3xN[el,az,rad] = cart2sph(array3xN[x,y,z])
                OR
                elevation, azimuth, radius = cart2sph(x,y,z)
                If working in DKL space, z = Luminance, y = S and x = LM
            """
            width = len(z)
            elevation = numpy.empty([width, width])
            radius = numpy.empty([width, width])
            azimuth = numpy.empty([width, width])
            radius = numpy.sqrt(x**2 + y**2 + z**2)
            azimuth = numpy.arctan2(y, x)
            # Calculating the elevation from x,y up
            elevation = numpy.arctan2(z, numpy.sqrt(x**2 + y**2))
            # convert azimuth and elevation angles into degrees
            azimuth *= 180.0 / numpy.pi
            elevation *= 180.0 / numpy.pi
            sphere = numpy.array([elevation, azimuth, radius])
            sphere = numpy.rollaxis(sphere, 0, 3)
            return sphere

        def sph2cart(*args):
            """Convert from spherical coordinates (elevation, azimuth, radius)
            to cartesian (x,y,z).
            usage:
                array3xN[x,y,z] = sph2cart(array3xN[el,az,rad])
                OR
                x,y,z = sph2cart(elev, azim, radius)
            """
            if len(args) == 1:  # received an Nx3 array
                elev = args[0][0, :]
                azim = args[0][1, :]
                radius = args[0][2, :]
                returnAsArray = True
            elif len(args) == 3:
                elev = args[0]
                azim = args[1]
                radius = args[2]
                returnAsArray = False
            z = radius * numpy.sin(radians(elev))
            x = radius * numpy.cos(radians(elev)) * numpy.cos(radians(azim))
            y = radius * numpy.cos(radians(elev)) * numpy.sin(radians(azim))
            if returnAsArray:
                return numpy.asarray([x, y, z])
            else:
                return x, y, z
        for obj in bpy.context.scene.objects:
            if "spk" in obj.name:
                bpy.data.objects[obj.name].select_set(True)
                print(obj.name, ' deleted')
                bpy.ops.object.delete()
        for block in bpy.data.meshes:
            if block.users == 0:
                bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            if block.users == 0:
                bpy.data.materials.remove(block)
        #file_path_rel = '//Assets/amadeus.blend'
        #preset_file_path_rel = '//hol/DEWI23.hol'
        #coord_convert_file_rel = '//scripts/coord_conversion.py'
        #
        #print(bpy.path.abspath(file_path_rel))
        #file_path = bpy.path.abspath(file_path_rel)
        #preset_file_path = bpy.path.abspath(preset_file_path_rel)
        #coord_convert_file = bpy.path.abspath(coord_convert_file_rel)
        #from coord_conv import sph2cart
        inner_path = 'Object'
        """
        Read *.hol file content
        """
        with open(preset_file_path) as f:
            preset_content = json.load(f)
            preset_dict = preset_content['hol']
            keys = list(preset_dict.keys())
        """
        Search in content for matching parameters
        """
        for i in range(1,128):
            sph_coord = [0,0,0]
            cart_coord = [0,0,0]
            spk_type = ""
            spk_color = [0,0,0,0]
            spk_pan = 0
            spk_tilt = 0
            spk_roll90deg = False
            speaker = '/speaker/'
            params = ['/color','/azim','/elev','/dist','/view3D/file3D','/view3D/roll90deg','/view3D/pan','/view3D/tilt']
            rotation_mode = 'XYZ'
            for param in params:
                tuple = (speaker,str(i),param)
                tuple = ''.join(tuple)
                if param == params[1]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        sph_coord[0] = p_tuple[0]
                        print(tuple,'azim:',p_tuple[0])
                elif param == params[2]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        sph_coord[1] = p_tuple[0]
                        print(tuple,'elev: ',p_tuple[0])
                elif param == params[3]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        sph_coord[2] = p_tuple[0]
                        print(tuple,'dist: ',p_tuple[0])
                        cart_coord = sph2cart(float(sph_coord[1]),float(sph_coord[0]),float(sph_coord[2]))
                        print('cartesian coordinates: ',cart_coord)
                elif param == params[4]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        end_loc = len(p_tuple)-5
                        spk_name = str(p_tuple[0])[19:end_loc]
                        print(tuple,spk_name)
                        bpy.ops.wm.append(
                            directory=os.path.join(file_path, inner_path),
                            filename=spk_name
                            )
                        for obj in bpy.context.selected_objects:
                            digits = len(str(i))
                            if digits == 1:
                                obj.name = 'spk.00'+str(i)+'.'+spk_name
                                obj.data.name = 'spk.00'+str(i)+'.'+spk_name
                                obj.location.x = cart_coord[1]
                                obj.location.y = cart_coord[0]
                                obj.location.z = cart_coord[2]
                                material = bpy.data.materials.new(name = 'spk.00'+str(i)+'.'+spk_name+'.mat')
                                obj.data.materials.append(material)
                                bpy.data.materials['spk.00'+str(i)+'.'+spk_name+'.mat'].diffuse_color = spk_color
                            elif digits == 2:
                                obj.name = 'spk.0'+str(i)+'.'+spk_name
                                obj.data.name = 'spk.0'+str(i)+'.'+spk_name
                                obj.location.x = cart_coord[1]
                                obj.location.y = cart_coord[0]
                                obj.location.z = cart_coord[2]
                                material = bpy.data.materials.new(name = 'spk.0'+str(i)+'.'+spk_name+'.mat')
                                obj.data.materials.append(material)
                                bpy.data.materials['spk.0'+str(i)+'.'+spk_name+'.mat'].diffuse_color = spk_color
                            else:
                                obj.name = 'spk.'+str(i)+'.'+spk_name
                                obj.data.name = 'spk.'+str(i)+'.'+spk_name
                                obj.location.x = cart_coord[1]
                                obj.location.y = cart_coord[0]
                                obj.location.z = cart_coord[2]
                                material = bpy.data.materials.new(name = 'spk.'+str(i)+'.'+spk_name+'.mat')
                                obj.data.materials.append(material)
                                bpy.data.materials['spk.'+str(i)+'.'+spk_name+'.mat'].diffuse_color = spk_color
                elif param == params[0]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        print(tuple,p_tuple)
                        spk_color = p_tuple
                elif param == params[7]:
                    obj.lock_rotation[1] = True
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        print(tuple,p_tuple)
                        spk_tilt = p_tuple[0]
                        for obj in bpy.context.selected_objects:
                            obj.rotation_mode = rotation_mode
                            """
                            if spk_roll90deg == True:
                                obj.rotation_euler[1] = math.radians(-float(spk_tilt))
                            else:
                                obj.rotation_euler[2] = math.radians(float(spk_tilt))
                            """
                            obj.rotation_euler[0] = math.radians(float(spk_tilt))
                            if float(spk_pan) > 90:
                                if spk_roll90deg == True:
                                    print('condition true')
                                    obj.rotation_euler[0] =  -1*(obj.rotation_euler[0])
                            obj.lock_rotation[0] = True
                elif param == params[6]:
                    obj.lock_rotation[2] = True
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        print(tuple,p_tuple)
                        spk_pan = p_tuple[0]
                        for obj in bpy.context.selected_objects:
                            obj.rotation_mode = rotation_mode
                            if spk_roll90deg == True:
                                obj.rotation_euler[1] = math.radians(float(spk_pan))
                                if float(spk_pan) > 90:
                                    print('modified to',obj.rotation_euler[0])
                                    obj.rotation_euler[2] = math.radians(-90)
                            else:
                                obj.rotation_euler[1] = math.radians(-float(spk_pan))
        #                    obj.rotation_euler[1] = math.radians(float(spk_pan))
                            obj.lock_rotation[1] = True
                elif param == params[5]:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        print(tuple,p_tuple)
                        spk_roll90deg = p_tuple[0]
                        if spk_roll90deg == True:
                            for obj in bpy.context.selected_objects:
                                rotation_mode = 'YZX'
                                obj.rotation_euler[2] = math.radians(90)
                                obj.lock_rotation[2] = True
                else:
                    if (tuple) in keys:
                        p_tuple = preset_dict[tuple]
                        print(tuple,p_tuple[0])
        """
        retrieve list of speaker models in assets file
        """
        """
        with bpy.data.libraries.load(file_path) as (data_from, data_to):
            object_names = [name for name in data_from.objects]
        #print(object_names)
        i = 17
        object_name = object_names[i]
        bpy.ops.wm.append(
            directory=os.path.join(file_path, inner_path),
            filename=object_name
            )
        for obj in bpy.context.selected_objects:
            obj.name = object_name
            obj.data.name = object_name
        """
        return {"FINISHED"}


class SNA_OT_Sources_Importer_Db826(bpy.types.Operator):
    bl_idname = "sna.sources_importer_db826"
    bl_label = "Sources_Importer"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_HOLOUTILS_12E4B(bpy.types.Panel):
    bl_label = 'HoloUtils'
    bl_idname = 'SNA_PT_HOLOUTILS_12E4B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'HoloUtils'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_OT_Add_Sources_73B0D(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.add_sources_73b0d"
    bl_label = "Add_Sources"
    bl_description = "replace actual tracks by those in imported hol preset file"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.hol', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        preset_file_path = self.filepath
        file_path = os.path.join(os.path.dirname(__file__), 'assets', 'amadeus.blend')
        Variable = None
        import json
        import numpy

        def cart2sph(z, y, x):
            """Convert from cartesian coordinates (x,y,z) to spherical (elevation,
            azimuth, radius). Output is in degrees.
            usage:
                array3xN[el,az,rad] = cart2sph(array3xN[x,y,z])
                OR
                elevation, azimuth, radius = cart2sph(x,y,z)
                If working in DKL space, z = Luminance, y = S and x = LM
            """
            width = len(z)
            elevation = numpy.empty([width, width])
            radius = numpy.empty([width, width])
            azimuth = numpy.empty([width, width])
            radius = numpy.sqrt(x**2 + y**2 + z**2)
            azimuth = numpy.arctan2(y, x)
            # Calculating the elevation from x,y up
            elevation = numpy.arctan2(z, numpy.sqrt(x**2 + y**2))
            # convert azimuth and elevation angles into degrees
            azimuth *= 180.0 / numpy.pi
            elevation *= 180.0 / numpy.pi
            sphere = numpy.array([elevation, azimuth, radius])
            sphere = numpy.rollaxis(sphere, 0, 3)
            return sphere

        def sph2cart(*args):
            """Convert from spherical coordinates (elevation, azimuth, radius)
            to cartesian (x,y,z).
            usage:
                array3xN[x,y,z] = sph2cart(array3xN[el,az,rad])
                OR
                x,y,z = sph2cart(elev, azim, radius)
            """
            if len(args) == 1:  # received an Nx3 array
                elev = args[0][0, :]
                azim = args[0][1, :]
                radius = args[0][2, :]
                returnAsArray = True
            elif len(args) == 3:
                elev = args[0]
                azim = args[1]
                radius = args[2]
                returnAsArray = False
            z = radius * numpy.sin(radians(elev))
            x = radius * numpy.cos(radians(elev)) * numpy.cos(radians(azim))
            y = radius * numpy.cos(radians(elev)) * numpy.sin(radians(azim))
            if returnAsArray:
                return numpy.asarray([y, x, z])
            else:
                return y, x, z
        for obj in bpy.context.scene.objects:
            if "track" in obj.name:
                bpy.data.objects[obj.name].select_set(True)
                print(obj.name, ' deleted')
                bpy.ops.object.delete()
        for block in bpy.data.meshes:
            if block.users == 0:
                bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            if block.users == 0:
                bpy.data.materials.remove(block)
        with open(preset_file_path) as f:
                hol_file_content = json.load(f)
                audio_engine_dict = hol_file_content['ae']
                print("ae",audio_engine_dict)
                hol_dict = hol_file_content['hol']
                hol_keys = list(hol_dict.keys())
        for i in range(1,128):
            global trk_name
            global trk_cart_coord
            global trk_sph_coord
            global trk_glb
            global trk_color
            trk_name =''
            trk_cart_coord = [0,0,0]
            inner_path = 'Object'    
            trk_sph_coord = [0,0,0]
            trk_color = [0,0,0,0]
            trk_glb = "Dodecahedron"
            digits = len(str(i))
            if digits == 1:
                trk_number = '00'+ str(i)
            elif digits == 2:
                trk_number = '0'+ str(i)
            else:
                trk_number = str(i)
            track ='/track/'
            params = ['/view3D/file3D','/color','/azim','/elev','/dist',"/name"]
            for param in params:
                tuple = (track,str(i),param)
                tuple = ''.join(tuple)
                if param == params[0]:
                    if tuple in hol_keys:
                        p_tuple = hol_dict[tuple]
                        end_loc = len(p_tuple)-5
                        trk_glb = str(p_tuple[0])[18:end_loc]
                        print(i,"j'ai un glb",trk_glb)
                elif param == params[1]:
                    col_path = [path for path in audio_engine_dict if tuple in path]
                    if col_path != []:
                        col_path = col_path[0].split()
                        for j in range(0,3):
                            trk_color[j] = float(col_path[j+1])
                            print(i,"j'ai une couleur",trk_color)
                elif param == params[2]:
                    azim_path = [path for path in audio_engine_dict if tuple in path]
                    if azim_path != []:
                        azim_path = azim_path[0].split()
                        trk_sph_coord[0] = float(azim_path[1])
                        print(i,"j'ai une azim",azim_path)
                elif param == params[3]:
                    elev_path = [path for path in audio_engine_dict if tuple in path]
                    if elev_path != []:
                        elev_path = elev_path[0].split()
                        trk_sph_coord[1] = float(elev_path[1])
                        print(i,"j'ai une elev",elev_path)
                elif param == params[4]:
                    dist_path = [path for path in audio_engine_dict if tuple in path]
                    if dist_path != []:
                        dist_path = dist_path[0].split()
                        trk_sph_coord[2] = float(dist_path[1])
                        trk_cart_coord = sph2cart(float(trk_sph_coord[1]),float(trk_sph_coord[0]),float(trk_sph_coord[2]))
                        print(i,"j'ai une dist",dist_path)
                elif param == params[5]:
                    name_path = [path for path in audio_engine_dict if tuple in path]
                    if name_path != []:
                        name_path = name_path[0].split('"')
                        trk_name = name_path[1]
                        print(i,"j'ai une name",name_path)
                if trk_name != "":
                    bpy.ops.wm.append(
                        directory=os.path.join(file_path, inner_path),
                        filename=trk_glb
                        )
                    print(i,'track',trk_number,'created as',trk_name)
                    for trk in bpy.context.selected_objects:
                        trk.name = track +"."+ trk_number +"."+ trk_name
                        trk.name = (trk.name).replace('/','')
                        trk.data.name = trk.name
                        for k in range(0,2):
                            trk.location[k] = trk_cart_coord[k]
                        trk_material = bpy.data.materials.new(name = trk.name+'.mat')
                        trk.data.materials.clear()
                        trk.data.materials.append(trk_material)
                        bpy.data.materials[trk.name+'.mat'].diffuse_color = trk_color
        """
                if "/track/" in audio_engine_dict[i]:
                    if '"' in audio_engine_dict[i]:
                        separate = str(audio_engine_dict[i]).split('"')
            #            print('separate"',separate)
                    else:
                        separate = str(audio_engine_dict[i]).split()
            #            print("separate ",separate)
                    path = separate[0]
                    path_details = path.split('/')
                    if int(len(path_details)) > 1:
                        if path_details[2] != "indices":
                            trk_number = path_details[2]
                            if len(trk_number) == 1:
                                trk_number = '00'+trk_number
                            elif len(trk_number) == 2:
                                trk_number = '0'+trk_number
                            else:
                                trk_number = trk_number
                            if int(len(path_details)) == 4:
                                path_key = path_details[3]
                                if "name" in path_key:
                                    print("that's name")
                                    trk_name = str(separate[1])
                                elif "color" in path_key:
                                    del separate[0]
                                    print("col_idx",separate)
                                    trk_color = []
                                    for item in separate:
                                        trk_color.append(float(item))
                                elif "azim" in path_key:
            #                        print("azim",float(separate[1]))
                                    trk_sph_coord[0] = float(separate[1])
                                elif "elev" in path_key:
            #                        print("elev",float(separate[1]))
                                    trk_sph_coord[1] = float(separate[1])
                                elif "dist" in path_key:
            #                        print("dist",float(separate[1]))
                                    trk_sph_coord[2] = float(separate[1])
            #                        print("trk_sph_coord",trk_sph_coord)
                                    trk_cart_coord = sph2cart(float(trk_sph_coord[1]),float(trk_sph_coord[0]),float(trk_sph_coord[2]))
            #                        print("trk_cart_coord",trk_cart_coord)
        """
        return {"FINISHED"}


class SNA_OT_Sources_Exporter_34F69(bpy.types.Operator, ExportHelper):
    bl_idname = "sna.sources_exporter_34f69"
    bl_label = "Sources_Exporter"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.json', options={'HIDDEN'} )
    filename_ext = '.json'

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        file_name = self.filepath
        tofile_datas = None
        ''' 
            example of script creating a json file (importable in nodeOSC panel) containing :
             -message handlers controlling x,y,z coordinates (and other stuffs) 
             of all objects in scene with 'track' string in their names.
             -message handlers using internal texts declared functions.
        '''
        import json
        from math import sqrt
        print("TEL EST LE NOM DU FICHIER", file_name)
        tofile_datas = ''
        datawrited = ''
        last_file_datas = ''

        default_path = os.path.expanduser("~")

        default_path = default_path.replace(os.sep, '/')

        default_path = default_path + "/Documents/blender3d" #here declare the folder where you want to save your file
        file_name= os.path.join(default_path,"holo_blend_OUTPUT.json") #here choose the name of your file
        objects = [obj.name for obj in bpy.context.scene.objects]
        matching = [s for s in objects if "track" in s]
        for x in matching:
            ob = bpy.data.objects[x]
            index = ((ob.name).split('.'))[1]
            id = int(index) 
            tofile_datas =  tofile_datas + '"/track/' + str(id) + '/x": {"data_path": "bpy.data.objects[\'' + ob.name +'\'].matrix_world.translation[0]","osc_type": "f","osc_index": "()","osc_direction": "OUTPUT","filter_repetition": false,"dp_format_enable": false,"dp_format": "args","loop_enable": false,"loop_range": "0, length, 1","enabled": true},"/track/' + str(id) + '/y": {"data_path": "bpy.data.objects[\'' + ob.name +'\'].matrix_world.translation[1]","osc_type": "f","osc_index": "()","osc_direction": "OUTPUT","filter_repetition": false,"dp_format_enable": false,"dp_format": "args","loop_enable": false,"loop_range": "0, length, 1","enabled": true},"/track/' + str(id) + '/z": {"data_path": "bpy.data.objects[\'' + ob.name +'\'].matrix_world.translation[2]","osc_type": "f","osc_index": "()","osc_direction": "OUTPUT","filter_repetition": false,"dp_format_enable": false,"dp_format": "args","loop_enable": false,"loop_range": "0, length, 1","enabled": true},"/track/' + str(id) + '/color": {"data_path": "bpy.data.objects[\'' + ob.name +'\'].color","osc_type": "f","osc_index": "(0,1,2,3)","osc_direction": "INPUT","filter_repetition": false,"dp_format_enable": false,"dp_format": "args","loop_enable": false,"loop_range": "0, length, 1","enabled": true},"/track/' + str(id) + '/name": {"data_path": "bpy.data.objects[\'' + ob.name +'\'].name","osc_type": "s","osc_index": "(0)","osc_direction": "INPUT","filter_repetition": false,"dp_format_enable": false,"dp_format": "args","loop_enable": false,"loop_range": "0, length, 1","enabled": false},'
        tofile_datas = '"/dump": {"data_path": \"exec(\\"f=bpy.data.texts[\'holo_in\'].as_module()' + '\\\\n' + 'f.dump(\'{0}\',\'{1}\')\\")\", "osc_type": "f", "osc_index": "()", "osc_direction": "INPUT", "filter_repetition": false, "dp_format_enable": true, "dp_format": "address, args[0]", "loop_enable": false, "loop_range": "0, length, 1", "enabled": false}, "/track/*": {"data_path": \"exec(\\"f=bpy.data.texts[\'holo_in\'].as_module()' + '\\\\n' + 'f.track(\'{0}\',\'{1}\')\\")\", "osc_type": "f", "osc_index": "()", "osc_direction": "INPUT", "filter_repetition": false, "dp_format_enable": true, "dp_format": "address, str(args).replace(\\"\'\\",\\"\\")", "loop_enable": false, "loop_range": "0, length, 1", "enabled": false},"/frames/str": {"data_path": \"exec(\\"f=bpy.data.texts[\'reaperTC\'].as_module()' + '\\\\n' + 'f.tc_to_frames(\'{0}\')\\")\", "osc_type": "f", "osc_index": "()", "osc_direction": "INPUT", "filter_repetition": false, "dp_format_enable": true, "dp_format": "args", "loop_enable": false, "loop_range": "0, length, 1", "enabled": true},' + tofile_datas
        tofile_datas = tofile_datas[:-1]
        tofile_datas = '{'+tofile_datas+'}'
        #with open(file_name, "w") as write_file:
        #    print('datas2 : ', tofile_datas)
        #    write_file.write(tofile_datas)
        #    print('data2 writed to file: ',file_name)
        #file = open(file_name, 'r')
        #datawrited = file.read()
        #print('datawrited',datawrited)
        #datawrited = datawrited[:-1]
        #last_file_datas = '{'+ datawrited +'}'
        #with open(file_name, "w") as write_file:
        #    write_file.write(last_file_datas)
        with open(self.filepath, mode='w') as file_B4DFA:
            file_B4DFA.seek(0)
            file_B4DFA.write(tofile_datas)
            file_B4DFA.truncate()
        return {"FINISHED"}


class SNA_PT_SPEAKERS_10CFD(bpy.types.Panel):
    bl_label = 'Speakers'
    bl_idname = 'SNA_PT_SPEAKERS_10CFD'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_12E4B'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=244, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.add_speakers_994c8', text='Import Speakers From .hol', icon_value=108, emboss=True, depress=False)


class SNA_PT_SOURCES_39AA3(bpy.types.Panel):
    bl_label = 'Sources'
    bl_idname = 'SNA_PT_SOURCES_39AA3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_12E4B'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=290, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.add_sources_73b0d', text='Import Sources  From .hol', icon_value=108, emboss=True, depress=False)
        op = layout.operator('sna.sources_exporter_34f69', text='Export Sources to OSC handlers', icon_value=702, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Add_Speakers_994C8)
    bpy.utils.register_class(SNA_OT_Sources_Importer_Db826)
    bpy.utils.register_class(SNA_PT_HOLOUTILS_12E4B)
    bpy.utils.register_class(SNA_OT_Add_Sources_73B0D)
    bpy.utils.register_class(SNA_OT_Sources_Exporter_34F69)
    bpy.utils.register_class(SNA_PT_SPEAKERS_10CFD)
    bpy.utils.register_class(SNA_PT_SOURCES_39AA3)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Add_Speakers_994C8)
    bpy.utils.unregister_class(SNA_OT_Sources_Importer_Db826)
    bpy.utils.unregister_class(SNA_PT_HOLOUTILS_12E4B)
    bpy.utils.unregister_class(SNA_OT_Add_Sources_73B0D)
    bpy.utils.unregister_class(SNA_OT_Sources_Exporter_34F69)
    bpy.utils.unregister_class(SNA_PT_SPEAKERS_10CFD)
    bpy.utils.unregister_class(SNA_PT_SOURCES_39AA3)
