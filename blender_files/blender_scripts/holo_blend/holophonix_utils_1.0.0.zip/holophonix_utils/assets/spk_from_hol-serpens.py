import bpy
import os
import json
import sys
import math

"""Functions and classes related to coordinate system conversion
"""
import numpy
from numpy import radians


def cart2pol(x, y, units='deg'):
    """Convert from cartesian to polar coordinates.

    :usage:

        theta, radius = cart2pol(x, y, units='deg')

    units refers to the units (rad or deg) for theta that should be returned
    """
    radius = numpy.hypot(x, y)
    theta = numpy.arctan2(y, x)
    if units in ('deg', 'degs'):
        theta = theta * 180 / numpy.pi
    return theta, radius



def pol2cart(theta, radius, units='deg'):
    """Convert from polar to cartesian coordinates.

    usage::

        x,y = pol2cart(theta, radius, units='deg')

    """
    if units in ('deg', 'degs'):
        theta = theta * numpy.pi / 180.0
    xx = radius * numpy.cos(theta)
    yy = radius * numpy.sin(theta)

    return xx, yy



def cart2sph(z, y, x):
    """Convert from cartesian coordinates (x,y,z) to spherical (elevation,
    azimuth, radius). Output is in degrees.

    usage:
        array3xN[el,az,rad] = cart2sph(array3xN[x,y,z])
        OR
        elevation, azimuth, radius = cart2sph(x,y,z)

        If working in DKL space, z = Luminance, y = S and x = LM
    """
    width = len(z)

    elevation = numpy.empty([width, width])
    radius = numpy.empty([width, width])
    azimuth = numpy.empty([width, width])

    radius = numpy.sqrt(x**2 + y**2 + z**2)
    azimuth = numpy.arctan2(y, x)
    # Calculating the elevation from x,y up
    elevation = numpy.arctan2(z, numpy.sqrt(x**2 + y**2))

    # convert azimuth and elevation angles into degrees
    azimuth *= 180.0 / numpy.pi
    elevation *= 180.0 / numpy.pi

    sphere = numpy.array([elevation, azimuth, radius])
    sphere = numpy.rollaxis(sphere, 0, 3)

    return sphere



def sph2cart(*args):
    """Convert from spherical coordinates (elevation, azimuth, radius)
    to cartesian (x,y,z).

    usage:
        array3xN[x,y,z] = sph2cart(array3xN[el,az,rad])
        OR
        x,y,z = sph2cart(elev, azim, radius)
    """
    if len(args) == 1:  # received an Nx3 array
        elev = args[0][0, :]
        azim = args[0][1, :]
        radius = args[0][2, :]
        returnAsArray = True
    elif len(args) == 3:
        elev = args[0]
        azim = args[1]
        radius = args[2]
        returnAsArray = False

    z = radius * numpy.sin(radians(elev))
    x = radius * numpy.cos(radians(elev)) * numpy.cos(radians(azim))
    y = radius * numpy.cos(radians(elev)) * numpy.sin(radians(azim))
    if returnAsArray:
        return numpy.asarray([x, y, z])
    else:
        return x, y, z

for obj in bpy.context.scene.objects:
    if "spk" in obj.name:
        bpy.data.objects[obj.name].select_set(True)
        print(obj.name, ' deleted')
        bpy.ops.object.delete()
        for block in bpy.data.meshes:
            if block.users == 0:
                bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            if block.users == 0:
                bpy.data.materials.remove(block)

 
#file_path_rel = '//Assets/amadeus.blend'
#preset_file_path_rel = '//hol/DEWI23.hol'
#coord_convert_file_rel = '//scripts/coord_conversion.py'
#
#print(bpy.path.abspath(file_path_rel))
#file_path = bpy.path.abspath(file_path_rel)
#preset_file_path = bpy.path.abspath(preset_file_path_rel)
#coord_convert_file = bpy.path.abspath(coord_convert_file_rel)
#from coord_conv import sph2cart
inner_path = 'Object'


"""
Read *.hol file content
"""
with open(preset_file_path) as f:
    preset_content = json.load(f)
    preset_dict = preset_content['hol']
    keys = list(preset_dict.keys())
    
"""
Search in content for matching parameters
"""
for i in range(1,128):
    sph_coord = [0,0,0]
    cart_coord = [0,0,0]
    spk_type = ""
    spk_color = [0,0,0]
    spk_pan = 0
    spk_tilt = 0
    spk_roll90deg = False
    speaker = '/speaker/'
    params = ['/color','/azim','/elev','/dist','/view3D/file3D','/view3D/roll90deg','/view3D/pan','/view3D/tilt']
    rotation_mode = 'XYZ'
    for param in params:
        tuple = (speaker,str(i),param)
        tuple = ''.join(tuple)
        
        if param == params[1]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[0] = p_tuple[0]
                print(tuple,'azim:',p_tuple[0])
        elif param == params[2]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[1] = p_tuple[0]
                print(tuple,'elev: ',p_tuple[0])
        elif param == params[3]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                sph_coord[2] = p_tuple[0]
                print(tuple,'dist: ',p_tuple[0])
                cart_coord = sph2cart(float(sph_coord[1]),float(sph_coord[0]),float(sph_coord[2]))
                print('cartesian coordinates: ',cart_coord)
        elif param == params[4]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                end_loc = len(p_tuple)-5
                spk_name = str(p_tuple[0])[19:end_loc]
                print(tuple,spk_name)
                bpy.ops.wm.append(
                    directory=os.path.join(file_path, inner_path),
                    filename=spk_name
                    )
                for obj in bpy.context.selected_objects:
                    digits = len(str(i))
                    if digits == 1:
                        obj.name = 'spk.00'+str(i)+'.'+spk_name
                        obj.data.name = 'spk.00'+str(i)+'.'+spk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
                        material = bpy.data.materials.new(name = 'spk.00'+str(i)+'.'+spk_name+'.mat')
                        obj.data.materials.append(material)
                        bpy.data.materials['spk.00'+str(i)+'.'+spk_name+'.mat'].diffuse_color = color
                    elif digits == 2:
                        obj.name = 'spk.0'+str(i)+'.'+spk_name
                        obj.data.name = 'spk.0'+str(i)+'.'+spk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
                        material = bpy.data.materials.new(name = 'spk.0'+str(i)+'.'+spk_name+'.mat')
                        obj.data.materials.append(material)
                        bpy.data.materials['spk.0'+str(i)+'.'+spk_name+'.mat'].diffuse_color = color
                    else:
                        obj.name = 'spk.'+str(i)+'.'+spk_name
                        obj.data.name = 'spk.'+str(i)+'.'+spk_name
                        obj.location.x = cart_coord[1]
                        obj.location.y = cart_coord[0]
                        obj.location.z = cart_coord[2]
                        material = bpy.data.materials.new(name = 'spk.'+str(i)+'.'+spk_name+'.mat')
                        obj.data.materials.append(material)
                        bpy.data.materials['spk.'+str(i)+'.'+spk_name+'.mat'].diffuse_color = color
                    
        elif param == params[0]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                color = p_tuple
                
        elif param == params[7]:
            obj.lock_rotation[1] = True
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                spk_tilt = p_tuple[0]
                for obj in bpy.context.selected_objects:
                    obj.rotation_mode = rotation_mode
                    """
                    if spk_roll90deg == True:
                        obj.rotation_euler[1] = math.radians(-float(spk_tilt))
                    else:
                        obj.rotation_euler[2] = math.radians(float(spk_tilt))
                    """
                    obj.rotation_euler[0] = math.radians(float(spk_tilt))
                    if float(spk_pan) > 90:
                        if spk_roll90deg == True:
                            print('condition true')
                            obj.rotation_euler[0] =  -1*(obj.rotation_euler[0])
                    obj.lock_rotation[0] = True
        elif param == params[6]:
            obj.lock_rotation[2] = True
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                spk_pan = p_tuple[0]
                for obj in bpy.context.selected_objects:
                    obj.rotation_mode = rotation_mode
                    if spk_roll90deg == True:
                        obj.rotation_euler[1] = math.radians(float(spk_pan))
                        if float(spk_pan) > 90:
                            print('modified to',obj.rotation_euler[0])
                            obj.rotation_euler[2] = math.radians(-90)
                            
                    else:
                        obj.rotation_euler[1] = math.radians(-float(spk_pan))
#                    obj.rotation_euler[1] = math.radians(float(spk_pan))
                    obj.lock_rotation[1] = True
                    
                        
        elif param == params[5]:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple)
                spk_roll90deg = p_tuple[0]
                if spk_roll90deg == True:
                    for obj in bpy.context.selected_objects:
                        rotation_mode = 'YZX'
                        obj.rotation_euler[2] = math.radians(90)
                        obj.lock_rotation[2] = True
                    
        else:
            if (tuple) in keys:
                p_tuple = preset_dict[tuple]
                print(tuple,p_tuple[0])
                    
    
"""
retrieve list of speaker models in assets file
"""
"""
with bpy.data.libraries.load(file_path) as (data_from, data_to):
    object_names = [name for name in data_from.objects]
#print(object_names)



i = 17
object_name = object_names[i]
 
bpy.ops.wm.append(
    directory=os.path.join(file_path, inner_path),
    filename=object_name
    )

for obj in bpy.context.selected_objects:
    obj.name = object_name
    obj.data.name = object_name
"""
