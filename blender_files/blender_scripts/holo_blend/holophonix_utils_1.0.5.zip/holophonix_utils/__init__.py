# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Holophonix_Utils",
    "author" : "Dewiweb", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 5),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper


addon_keymaps = {}
_icons = None
class SNA_OT_Add_Sources_73B0D(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.add_sources_73b0d"
    bl_label = "Add_Sources"
    bl_description = "replace actual tracks by those in imported hol preset file"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.hol', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        preset_file_path = self.filepath
        file_path = os.path.join(os.path.dirname(__file__), 'assets', 'amadeus.blend')
        Variable = None
        return {"FINISHED"}


class SNA_OT_Sources_Exporter_34F69(bpy.types.Operator, ExportHelper):
    bl_idname = "sna.sources_exporter_34f69"
    bl_label = "Sources_Exporter"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.json', options={'HIDDEN'} )
    filename_ext = '.json'

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        file_name = self.filepath
        tofile_datas = None
        with open(self.filepath, mode='w') as file_B4DFA:
            file_B4DFA.seek(0)
            file_B4DFA.write(tofile_datas)
            file_B4DFA.truncate()
        return {"FINISHED"}


class SNA_OT_Add_Speakers_994C8(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.add_speakers_994c8"
    bl_label = "Add_Speakers"
    bl_description = "replace actual speakers by those in imported hol preset file"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.hol', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        preset_file_path = self.filepath
        file_path = os.path.join(os.path.dirname(__file__), 'assets', 'amadeus.blend')
        Variable = None
        return {"FINISHED"}


class SNA_OT_Import_An_Tree_433Db(bpy.types.Operator):
    bl_idname = "sna.import_an_tree_433db"
    bl_label = "Import_AN_Tree"
    bl_description = "Import AN Tree"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        Variable = None
        import os
        inner_path = 'NodeTree'
        file_path = '/home/dewi/Github/chataigne_spatiale/blender_files/blender_scripts/holo_blend/holo_python_queue.blend'
        name = 'AN Tree'
        bpy.ops.wm.append(
                    directory=os.path.join(file_path, inner_path),
                    filename=name
                    ) 
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_HOLOUTILS_6F3FD(bpy.types.Panel):
    bl_label = 'HoloUtils'
    bl_idname = 'SNA_PT_HOLOUTILS_6F3FD'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'HoloUtils'
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.template_icon(icon_value=_icons['logo_svg_blanc.png'].icon_id, scale=2.0)


class SNA_PT_SOURCES_C8ADB(bpy.types.Panel):
    bl_label = 'Sources'
    bl_idname = 'SNA_PT_SOURCES_C8ADB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_6F3FD'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=290, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.add_sources_73b0d', text='Import Sources  From .hol', icon_value=108, emboss=True, depress=False)
        op = layout.operator('sna.sources_exporter_34f69', text='Export Sources to OSC handlers', icon_value=702, emboss=True, depress=False)


class SNA_PT_SPEAKERS_5537E(bpy.types.Panel):
    bl_label = 'Speakers'
    bl_idname = 'SNA_PT_SPEAKERS_5537E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_6F3FD'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=244, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.add_speakers_994c8', text='Import Speakers From .hol', icon_value=108, emboss=True, depress=False)


class SNA_PT_AN_SETTINGS_ED232(bpy.types.Panel):
    bl_label = 'AN Settings'
    bl_idname = 'SNA_PT_AN_SETTINGS_ED232'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_6F3FD'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=233, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.import_an_tree_433db', text='Import AN Tree', icon_value=119, emboss=True, depress=False)
        layout.prop(bpy.data.node_groups['AN Tree'].nodes['Data Input'].inputs[0], 'value', text='Path to dump', icon_value=0, emboss=True, expand=True)
        layout.prop(bpy.data.node_groups['AN Tree'].nodes['Data Input.001'].inputs[0], 'value', text='View Names', icon_value=0, emboss=True)


class SNA_PT_NODEOSC_SETTINGS_D06C0(bpy.types.Panel):
    bl_label = 'NodeOSC Settings'
    bl_idname = 'SNA_PT_NODEOSC_SETTINGS_D06C0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HOLOUTILS_6F3FD'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (True)

    def draw_header(self, context):
        layout = self.layout
        layout.template_icon(icon_value=233, scale=1.2100000381469727)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('nodeosc.deleteitem', text='My Button', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Add_Sources_73B0D)
    bpy.utils.register_class(SNA_OT_Sources_Exporter_34F69)
    bpy.utils.register_class(SNA_OT_Add_Speakers_994C8)
    bpy.utils.register_class(SNA_OT_Import_An_Tree_433Db)
    bpy.utils.register_class(SNA_PT_HOLOUTILS_6F3FD)
    if not 'logo_svg_blanc.png' in _icons: _icons.load('logo_svg_blanc.png', os.path.join(os.path.dirname(__file__), 'icons', 'logo_svg_blanc.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_SOURCES_C8ADB)
    bpy.utils.register_class(SNA_PT_SPEAKERS_5537E)
    bpy.utils.register_class(SNA_PT_AN_SETTINGS_ED232)
    bpy.utils.register_class(SNA_PT_NODEOSC_SETTINGS_D06C0)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Add_Sources_73B0D)
    bpy.utils.unregister_class(SNA_OT_Sources_Exporter_34F69)
    bpy.utils.unregister_class(SNA_OT_Add_Speakers_994C8)
    bpy.utils.unregister_class(SNA_OT_Import_An_Tree_433Db)
    bpy.utils.unregister_class(SNA_PT_HOLOUTILS_6F3FD)
    bpy.utils.unregister_class(SNA_PT_SOURCES_C8ADB)
    bpy.utils.unregister_class(SNA_PT_SPEAKERS_5537E)
    bpy.utils.unregister_class(SNA_PT_AN_SETTINGS_ED232)
    bpy.utils.unregister_class(SNA_PT_NODEOSC_SETTINGS_D06C0)
